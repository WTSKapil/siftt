=== Siftt ===

Contributors: automattic
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready

Requires at least: 4.5
Tested up to: 5.4
Requires PHP: 5.6
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: LICENSE

A starter theme called siftt.

== Description ==

Siftt Theme is a Fully Responsive customize WordPress Theme.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.
4. Theme activate then first create new page with name 'Home' and this page in select 'Home Template' then publish this page.
5. Create page then go to Appearance > Menus and create a new menu 'Main Menu' with name.
6. Main Menu in add Home page block name and block ID. For ex. Navigation label is 'About' and URL is '#about'. then click on save menu button.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Siftt includes support for Infinite Scroll in Jetpack.

== Changelog ==

= 1.0 - May 19 2025 =
* Initial release

== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2020 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2018 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)
